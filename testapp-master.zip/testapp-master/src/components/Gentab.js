import React from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-alpine.css";
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

class Gentab extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      rowData: props.tableDef.rowData,
      columnDefs: props.tableDef.columnDefs,
      defaultColDef: props.tableDef.defaultColDef,
      title: props.title,
      context: props.context,
      showForm:false
    };
  }


  onGridReady = (params) => {
    //alert('Grid is ready' );
    this.api = params.api;
    this.columnApi = params.columnApi;
    this.columnApi.autoSizeAllColumns(false);
  }

  showForm = () => {
    return (
        <Form>
          <Form.Group className="mb-3" controlId="formBasicCOl">
            <Form.Label>Column:</Form.Label>
            <Form.Control placeholder="Table column" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicCode">
            <Form.Label>Constraint Code:</Form.Label>
            <Form.Control placeholder="Constraint Code" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicDatab">
            <Form.Label>Database:</Form.Label>
            <Form.Control placeholder="Database" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicTable">
            <Form.Label>Table:</Form.Label>
            <Form.Control placeholder="Table" />
          </Form.Group>
          <Form.Group className="mb-3" controlId="formBasicCheckbox">
            <Form.Check type="checkbox" label="Enable" />
          </Form.Group>
          <Button variant="primary" className="mr-2" type="submit">
            Create analyzer
          </Button>
          <Button variant="secondary" onClick={() => this.setState({showForm: false}) }>
            Cancel
          </Button>
        </Form>
      );
  }

  render() {
    return (
      <div>
        <h1>{this.state.title}</h1>
        {this.state.title == 'Analyzers'  &&  this.state.showForm == false && <Button onClick={() => this.setState({showForm: true}) } variant="primary">
            Add analyzer
        </Button>
        }
        { this.state.title == 'Analyzers' && this.state.showForm == true && this.showForm() }
        <br />
        { this.state.title == 'Analyzers' && <br /> }
        <div
          className="ag-theme-alpine"
          style={{ height: "600px", width: "900px" }}
        >
          <AgGridReact
            onGridReady={this.onGridReady}
            rowSelection="single"
            defaultColDef={this.state.defaultColDef}
            columnDefs={this.state.columnDefs}
            rowData={this.state.rowData}
            context={this.state.context}
          />
        </div>
      </div>
    );
  }
}

export default Gentab;
