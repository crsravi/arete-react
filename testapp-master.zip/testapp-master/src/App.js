import React from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Navigator from "./components/Navigator";
import "./styles.css";
import Gentab from "./components/Gentab";
import Scope from "./components/Scope";
import EditButton from './components/EditButton'
import DeleteButton from './components/DeleteButton'

class App extends React.Component {
  constructor(props) {
    super(props);

    let hdrID = {
      headerName: "Id",
      field: "id",
      sortable: true,
      checkBoxSelection: true,
      filter: true
    };
    let hdrName = {
      headerName: " Constraint Suggestion",
      field: "name",
      sortable: true,
      filter: true
    };
    let hdrDesc = {
      headerName: "Scala code",
      field: "description",
      sortable: true,
      filter: true
    };
    let hdrEnv = {
      headerName: "Env",
      field: "env",
      sortable: true,
      filter: true
    };

    let hdrClientID = {
      headerName: "Client Id",
      field: "clientId",
      sortable: true,
      filter: true
    };
    let hdrScopeID = {
      headerName: "Scope Id",
      field: "scopeId",
      sortable: true,
      filter: true
    };

    let hdrEffectiveDate = {
      headerName: "Effective Date",
      field: "effectiveDate",
      sortable: true,
      filter: true
    };
    let hdrExpiryDate = {
      headerName: "ExpiryDate",
      field: "expiryDate",
      sortable: true,
      filter: true
    };
    let hdrCheck = {
      headerName: "Check",
      field: "check",
      checkBoxSelection: true
    };

    let hdrEdit = {
      headerName: 'Disable',
      field: 'value',
      cellRendererFramework: EditButton,
      colId: 'params',
      width: 180,    header: "Disable",
      filterable: false,

    }

    let hdrDelete = {
      headerName: 'Delete',
      field: 'value',
      cellRendererFramework: DeleteButton,
      colId: 'params',
      width: 180,    header: "Delete",
      filterable: false,

    }

    let hdrAccess = {
      headerName: "Access",
      field: "access",
      sortable: true,
      filter: true
    };

    let scopeData = {
      defaultColDef: { editable: true },
      columnDefs: [
        hdrID,
        hdrName,
        hdrDesc,
	      {
          headerName: "Enabled",
          field: "domain",
          sortable: true,
          filter: true
        },
        hdrEdit,
        hdrDelete,
      ],
      rowData: [
        { id: "1", name: "apiPerimissionRead", description: "apiPerimissionRead", domain: "Y" },
        { id: "2", name: "apiPerimissionUpdate", description: "apiPerimissionUpdate", domain: "N" },
        { id: "3", name: "apiPreferenceRead", description: "apiPreferenceRead", domain: "Y" },
        { id: "4", name: "apiPreferenceUpdate", description: "apiPreferenceUpdate", domain: "Y" },
        { id: "5", name: "apiNameDefRead", description: "apiNameDefRead", domain: "Y" },
        { id: "6", name: "apiNameDefUpdate", description: "apiNameDefUpdate", domain: "N" },
        { id: "7", name: "validateApiCallRead", description: "validateApiCallRead", domain: "Y" },
        { id: "8", name: "validateApiCallUpdate", description: "validateApiCallUpdate", domain: "N" },
        { id: "9", name: "apiAcccountInfoRead", description: "apiAcccountInfoRead", domain: "Y" },
        { id: "10", name: "apiAccountUpdate", description: "apiAccountUpdate", domain: "N" }
      ]
    };

    let clientScopeData = {
      columnDefs: [hdrClientID, hdrScopeID, hdrEdit, hdrDelete],
      rowData: [
        { clientId: "C3", scopeId: "S3" },
        { clientId: "C3", scopeId: "S4" },
        { clientId: "C1", scopeId: "S3" },
        { clientId: "C1", scopeId: "S4" },
        { clientId: "C2", scopeId: "S3" },
        { clientId: "C2", scopeId: "S4" },
        { clientId: "C1", scopeId: "S12" },
        { clientId: "C1", scopeId: "S10" }
      ]
    };

    let domainData = {
      title: "Domain",
      columnDefs: [hdrID, hdrDesc, hdrEdit, hdrDelete],
      rowData: [
        { id: "abc", description: "Customer" },
        { id: "def", description: "Enterprise"},
        { id: "ghi", description: "Managment"},
        { id: "jkl", description: "Relations"}
      ]
    };

    let clientData = {
      columnDefs: [hdrID, hdrName, hdrDesc, hdrEnv, hdrEdit, hdrDelete],
      rowData: [
        { id: "C1", name: "Client1", description: "client1", env: "Test" },
        { id: "C2", name: "Client1", description: "client1", env: "Prod" },
        { id: "C3", name: "Client1", description: "client1", env: "Dev" },
        { id: "C4", name: "Client2", description: "client2", env: "Test" },
        { id: "C5", name: "Client2", description: "Client2", env: "Prod" },
        { id: "C6", name: "Client2", description: "Client2", env: "Dev" }
      ]
    };

    let apiData = {
      defaultColDef: { editable: true },
      columnDefs: [
        hdrID,
        hdrName,
        hdrDesc,
	      {
          headerName: "Enabled",
          field: "domain",
          sortable: true,
          filter: true
        },
        hdrEdit,
        hdrDelete,
      ],
      rowData: [
        { id: "1", name: "apiPerimissionRead", description: "apiPerimissionRead", domain: "Y" },
        { id: "2", name: "apiPerimissionUpdate", description: "apiPerimissionUpdate", domain: "N" },
        { id: "3", name: "apiPreferenceRead", description: "apiPreferenceRead", domain: "Y" },
        { id: "4", name: "apiPreferenceUpdate", description: "apiPreferenceUpdate", domain: "Y" },
        { id: "5", name: "apiNameDefRead", description: "apiNameDefRead", domain: "Y" },
        { id: "6", name: "apiNameDefUpdate", description: "apiNameDefUpdate", domain: "N" },
        { id: "7", name: "validateApiCallRead", description: "validateApiCallRead", domain: "Y" },
        { id: "8", name: "validateApiCallUpdate", description: "validateApiCallUpdate", domain: "N" },
        { id: "9", name: "apiAcccountInfoRead", description: "apiAcccountInfoRead", domain: "Y" },
        { id: "10", name: "apiAccountUpdate", description: "apiAccountUpdate", domain: "N" }
      ]
    };

    this.state = {
      apiData: apiData,
      scopeData: scopeData,
      scopeColumnDefs:scopeData.columnDefs,
      scopeRowData:scopeData.rowData,
      clientScopeData : clientScopeData,
      domainData:domainData,
      clientData:clientData,
      context: { componentParent: this }
    };
  }

  methodFromParent = cell => {
    alert('Parent Component Method from ' + cell + '!');
  }

  render() {
    return (
      <BrowserRouter>
        <div className="container">
          <Navigator/>
          <Switch>
            <Route path="/" component={(routeProps) => <Gentab title="Data Quality Constraint Suggestions" context={this.state.context} tableDef={this.state.apiData} {...routeProps} /> } exact />
            <Route path="/api" component={(routeProps) => <Gentab title="Data Quality Constraint Suggestions" context={this.state.context} tableDef={this.state.apiData} {...routeProps} /> } />
            <Route path="/scope" component={(routeProps) => <Scope title="Analyzers" context={this.state.context} tableDef={this.state.scopeData} {...routeProps} /> } />
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
