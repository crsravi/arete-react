import Gentab from "./Gentab"

class Scope extends Gentab
{
}

export default Scope;